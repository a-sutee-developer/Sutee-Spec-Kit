#!/usr/bin/env bash
# Install/Uninstall Sutee CLI

set -euo pipefail

# Check for uninstall flag
if [[ "${1:-}" == "--uninstall" ]] || [[ "${1:-}" == "-u" ]]; then
    echo "=== Sutee CLI 卸载器 ==="
    echo
    
    INSTALL_DIR="$HOME/.local/bin"
    BINARY_NAME="sutee"
    TARGET="$INSTALL_DIR/$BINARY_NAME"
    
    if [[ -f "$TARGET" ]]; then
        rm -f "$TARGET"
        echo "✅ 已删除: $TARGET"
        echo
        echo "卸载完成!"
        echo
        echo "如需重新安装,请运行: ./install-local.sh"
    else
        echo "⚠️  未找到安装文件: $TARGET"
        echo "可能已经被卸载"
    fi
    exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Try to find binary in current directory first (for release package)
if [[ -f "$SCRIPT_DIR/sutee" ]]; then
    BINARY_SOURCE="$SCRIPT_DIR/sutee"
elif [[ -f "$SCRIPT_DIR/target/sutee" ]]; then
    BINARY_SOURCE="$SCRIPT_DIR/target/sutee"
else
    echo "❌ 未找到 sutee 二进制文件"
    echo "请确保在正确的目录运行此脚本"
    exit 1
fi

echo "=== Sutee CLI 安装器 ==="
echo

# Detect platform
OS="$(uname -s)"
ARCH="$(uname -m)"

case "$OS" in
    Darwin)
        if [[ "$ARCH" == "arm64" ]]; then
            PLATFORM="macOS ARM64"
        else
            PLATFORM="macOS Intel"
        fi
        BINARY_NAME="sutee"
        ;;
    Linux)
        PLATFORM="Linux"
        BINARY_NAME="sutee"
        ;;
    MINGW*|MSYS*|CYGWIN*)
        PLATFORM="Windows"
        BINARY_NAME="sutee.exe"
        ;;
    *)
        echo "❌ 不支持的操作系统: $OS"
        exit 1
        ;;
esac

echo "检测到平台: $PLATFORM"
echo "源文件: $BINARY_SOURCE"
echo "文件大小: $(du -h "$BINARY_SOURCE" | cut -f1)"
echo

# Install directory
INSTALL_DIR="$HOME/.local/bin"
TARGET="$INSTALL_DIR/$BINARY_NAME"

# Create install directory
mkdir -p "$INSTALL_DIR"

# Copy binary
echo "安装到: $TARGET"
cp "$BINARY_SOURCE" "$TARGET"
chmod +x "$TARGET"

echo
echo "✅ 安装成功!"
echo

# Verify installation
if command -v "$BINARY_NAME" &> /dev/null; then
    VERSION=$("$BINARY_NAME" --version 2>/dev/null || echo "未知")
    echo "已安装版本: $VERSION"
else
    echo "⚠️  $INSTALL_DIR 不在 PATH 中"
    echo
    echo "请运行以下命令添加到 PATH："
    case "$SHELL" in
        */zsh)
            echo "  echo 'export PATH=\"\$HOME/.local/bin:\$PATH\"' >> ~/.zshrc"
            echo "  source ~/.zshrc"
            ;;
        */bash)
            echo "  echo 'export PATH=\"\$HOME/.local/bin:\$PATH\"' >> ~/.bashrc"
            echo "  source ~/.bashrc"
            ;;
        *)
            echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
            ;;
    esac
fi

echo
echo "🎯 快速开始:"
echo "  $BINARY_NAME --help              # 查看帮助"
echo "  $BINARY_NAME check               # 检查环境"
echo "  $BINARY_NAME init . --ai claude  # 初始化项目"
echo
echo "💡 如需卸载:"
echo "  ./install-local.sh --uninstall   # 卸载 CLI"
echo
